/** Automatically generated file. DO NOT MODIFY */
package com.example.shop_map;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}